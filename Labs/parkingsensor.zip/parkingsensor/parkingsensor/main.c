/*
 * parkingsensor.c
 *
 * Created: 03.12.2020 13:33:19
 * Author : Vori
 */ 

/* Includes ----------------------------------------------------------*/
#ifndef F_CPU
#define F_CPU 16000000
#endif

#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include <stdlib.h>         // C library. Needed for conversion function
#include <stdio.h>
#include <util/delay.h>
#include "uart.h"           // Peter Fleury's UART library
#include "gpio.h"  
#include "lcd.h"
#include "lcd_definitions.h"    

#define Front_trigger PB3
#define Back_trigger  PB2
#define Front_Echo	  PD3
#define Back_Echo	  PD2


volatile uint8_t trigger_enable = 1;	//trigger enable flag
volatile uint8_t trigger_id = 1;		
volatile float Front_distance=0;
volatile float Back_distance=0;
char lcd_string[50];

int main(void)
{
	lcd_init(LCD_DISP_ON);
	lcd_gotoxy(1, 0);
	lcd_puts("dist_front:");
	lcd_gotoxy(1, 2);
	lcd_puts("dist_back :");
	
	uart_init(UART_BAUD_SELECT(9600,F_CPU));
	
	//configure echo pins as inputs without pull up resistor
	GPIO_config_input_nopull(&DDRD, Front_Echo);
	GPIO_config_input_nopull(&DDRD, Back_Echo);
	
	//configure trigger pins as outputs and set them to low
	GPIO_config_output(&DDRB, Front_trigger);
	GPIO_write_low(&PORTB, Front_trigger);
	GPIO_config_output(&DDRB, Back_trigger);
	GPIO_write_low(&PORTB, Back_trigger);
	
	//Rising edge of INT1 generates an interrupt request
	EICRA |= (1 << ISC11) | (1 << ISC10);   
	EIMSK |= (1 << INT1);
	
	
	//Rising edge of INT0 generates an interrupt request
	EICRA |= (1 << ISC01) | (1 << ISC00);
	EIMSK |= (1 << INT0);
	
	sei(); //enable interrupts

    while (1) 
    {
		
	   if (trigger_enable==1 && trigger_id ==2)
		   {
			   //send start pulse to front sensor
				GPIO_write_high(&PORTB,Front_trigger);
				_delay_us(10);
				GPIO_write_low(&PORTB,Front_trigger);
				trigger_enable = 0;						
		   }

		if (trigger_enable==1 && trigger_id == 1)
			{
				//send start pulse to back sensor
				GPIO_write_high(&PORTB,Back_trigger);				
				_delay_us(10);
				GPIO_write_low(&PORTB,Back_trigger);
				trigger_enable = 0;						
			}
			
		//display distance to front obstacle
		if (trigger_id==2)
		{
			trigger_id=1;							  //change sensor for next loop
			Front_distance=Front_distance*(0.15008);  //TO BE OPTIMIZED
			
			itoa(Front_distance, lcd_string, 10);     // Convert decimal value to string
			if (Front_distance<10)
			{
				lcd_gotoxy(14,0);
				lcd_puts("  ");
				lcd_gotoxy(16, 0);
			}
			else if (Front_distance>10 && Front_distance<100)
			{
				lcd_gotoxy(14,0);
				lcd_puts(" ");
				lcd_gotoxy(15, 0);
			}
			else
			{
				lcd_gotoxy(14, 0);
			}

			lcd_puts(lcd_string);
		}
		//display distance to back obstacle
		else
		{
			trigger_id=2;							//change sensor for next loop

			Back_distance=Back_distance*(0.15008);	//TO BE OPTIMIZED
			
			itoa(Back_distance, lcd_string, 10);    // Convert decimal value to string
			if (Back_distance<10)
			{
				lcd_gotoxy(14,1);
				lcd_puts("  ");
				lcd_gotoxy(16, 1);
			}
			
			else if (Back_distance>10 && Back_distance<100)
			{
				lcd_gotoxy(14,1);
				lcd_puts(" ");
				lcd_gotoxy(15, 1);
			}
			else
			{
				lcd_gotoxy(14, 1);
			}
			
			lcd_puts(lcd_string);	
		}
    }	
}

ISR(INT1_vect){
	do
	{ 
		Front_distance++;					//keep counting
	} while (GPIO_read(&PIND,Front_Echo));	//until echo is 0
	trigger_enable=1;						//enable trigger
}

ISR(INT0_vect){
	do
	{ 
		Back_distance++;					//keep counting
	} while (GPIO_read(&PIND,Back_Echo));	//until echo is 0
	trigger_enable=1;						//enable trigger
}